# My Tailwind Portfolio

This is a personal portfolio website built using HTML and Tailwind CSS. It features:

- Fully responsive design
- About Me, Projects, and Contact sections
- Resume download button
- No JavaScript or custom CSS

## Experience

I learned how to use Tailwind’s utility classes effectively for layout and design. The project helped me structure my personal website and focus on responsiveness and UI clarity.
